from mpl_toolkits import mplot3d
import numpy as np
import matplotlib.pyplot as plt
import math
import scipy.linalg as lin

def rotate_mat(axis, degree):
	radian = float(degree)/180*math.pi
	rot_matrix = lin.expm(np.cross(np.eye(3), axis/lin.norm(axis)*radian))
	return rot_matrix

log_path = 'C:\\Users\\The Lab\\Desktop\\ETS test environment\\ETS Test Environment Vol. 0.5\\Movement\\'
name = input('Enter the name of participate: ')

fo = open(log_path+'MovementLog_'+name+'.txt.', 'r')
lines = fo.readlines()

positions = []
directions = []
timestamps = []

axis_x, axis_y, axis_z = [1,0,0], [0,1,0], [0,0,1]

first = True
for line in lines:
	if first:
		first = False
		continue

	str = line.split(', (')
	timestamps.append(float(str[0]))
	positions.append(np.array(str[1][:-1].split(', '), dtype=float))
	directions.append(np.array(str[2][:-2].split(', '), dtype=float))

timestamps = np.array(timestamps)
positions = np.array(positions)
directions = np.array(directions)


fig = plt.figure()
ax = plt.gca(projection = '3d')
ax.plot3D(positions[:,0], positions[:,2], positions[:,1], 'gray')

num = len(positions)

first = True
for i in range(num):
	s = positions[i]
	d = directions[i]
	ax.quiver(s[0],s[2],s[1],d[0],d[2],d[1],normalize = True)



plt.axis([-5, 5, -5, 5])
ax.set_xlabel( "X" )
ax.set_ylabel( "Y" )
ax.set_zlabel( "Z" )
ax.set_zlim(-5, 5)
plt.show()