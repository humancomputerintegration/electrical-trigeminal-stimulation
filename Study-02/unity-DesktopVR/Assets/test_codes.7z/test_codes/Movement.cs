﻿/*
 * By: Jingxuan Wen (comments by Jas Brooks)
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

public class Movement : MonoBehaviour
{
    public int LoggingTimeInterval = 10; // Currently, this is set up to be every 10 frames. Change to a certain number of milliseconds.
    public string ParticipantNumber = "Jingxuan";
    public string SaveLogFileTo = "C:\\Users\\The Lab\\Desktop\\ETS test environment\\ETS Test Environment Vol. 0.5\\Movement\\";

    /*
    private List<float> timeLog = new List<float>();
    private List<Vector3> positionLog = new List<Vector3>();
    private List<Vector3> directionLog = new List<Vector3>();
    */
    StreamWriter sw = null;
    
    void Start()
    {
        /*
        timeLog.Clear();
        positionLog.Clear();
        directionLog.Clear();
        */
        string filename = SaveLogFileTo + "MovementLog_" + ParticipantNumber + ".txt";
        sw = new StreamWriter(filename);
        sw.WriteLine("time ---> nose (camera) position ---> nose(camera) direction");
        sw.Flush();
    }
    
    void Update()
    {
        if(Time.frameCount % LoggingTimeInterval == 0)
        {
            sw.WriteLine(Time.time + ", " + transform.position + ", " + transform.forward);
            sw.Flush();
            /*
            timeLog.Add(Time.time);
            positionLog.Add(transform.position);
            directionLog.Add(transform.forward);
            */
        }
    }

    /*
    private void OnApplicationQuit()
    {
        using (StreamWriter outputFile = new StreamWriter("MovementLog.txt"))
        {
            outputFile.WriteLine("time ---> nose (camera) position ---> nose(camera) direction");
            int count = 0;
            foreach (float time in timeLog)
            {
                outputFile.WriteLine(time + ", " + positionLog[count] + ", " + directionLog[count]);
                count++;
            }
        }
    }*/
}
