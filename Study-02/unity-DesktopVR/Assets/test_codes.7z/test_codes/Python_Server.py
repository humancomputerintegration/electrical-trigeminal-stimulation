import argparse
import math
import string
from rehamove import *
import time

from pythonosc import dispatcher
from pythonosc import osc_server


# Stimulation
def print_ETS_info(unused_addr, args, message):
    if message == 0:
        pulse = [(-1, 300), (-1,100)]
        side = 'left'
    else:
        pulse = [(1, 300), (-1,100)]
        side = 'right'
    
    for i in range(0,5): # increasing
        r.custom_pulse(currentChannel, pulse)
        time.sleep(0.01)
    
    print('ETS is on the ' + side + ' side\n')


# Main
if __name__ == "__main__":
    # ETS initialization
    r = Rehamove("COM18")   # Open USB port (on VIVE)
    currentChannel = "red"

    # Listening to the port
    parser = argparse.ArgumentParser()
    parser.add_argument("--ip", default="127.0.0.1", help = "The ip to listen on")
    parser.add_argument("--port", type=int, default=9001, help = "The port to listen on")
    args = parser.parse_args()

    # Deal with the message
    dispatcher = dispatcher.Dispatcher()
    dispatcher.map("/stimulation", print_ETS_info, "dummy")

    server = osc_server.ThreadingOSCUDPServer((args.ip, args.port), dispatcher)
    print('Serving on {}'.format( server.server_address))
    server.serve_forever()
