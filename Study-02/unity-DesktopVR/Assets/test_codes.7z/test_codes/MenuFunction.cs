﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuFunction : MonoBehaviour
{

    public GameObject Menu;

    public void ConfirmAndContinue()
    {
        Menu.SetActive(false);
        Time.timeScale = 1f;
        ControllerMapping.TestIsPaused = false;
        //Debug.Log("Confirm button pressed");
    }

    public void LeftCheck()
    {
        Unity_Client.SendStimulation(1);
    }

    public void LeftIncrease()
    {
        Unity_Client.IntensityFactor = 
    }
}
